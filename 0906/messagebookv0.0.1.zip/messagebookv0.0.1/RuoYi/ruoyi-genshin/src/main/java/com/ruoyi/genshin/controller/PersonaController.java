package com.ruoyi.genshin.controller;

import java.util.List;

import com.ruoyi.genshin.domain.Attr;
import com.ruoyi.genshin.service.IAttrService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.genshin.domain.Persona;
import com.ruoyi.genshin.service.IPersonaService;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 角色信息表Controller
 * 
 * @author ruoyi
 * @date 2022-09-05
 */
@Controller
@RequestMapping("/genshin/persona")
public class PersonaController extends BaseController
{
    private String prefix = "genshin/persona";

    @Autowired
    private IPersonaService personaService;

    @Autowired
    private IAttrService attrService;

    @RequiresPermissions("genshin:persona:view")
    @GetMapping()
    public String persona()
    {
        return prefix + "/persona";
    }

    /**
     * 查询角色信息表列表
     */
    @RequiresPermissions("genshin:persona:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(Persona persona)
    {
        startPage();
        List<Persona> list = personaService.selectPersonaList(persona);
        return getDataTable(list);
    }

    /**
     * 导出角色信息表列表
     */
    @RequiresPermissions("genshin:persona:export")
    @Log(title = "角色信息表", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(Persona persona)
    {
        List<Persona> list = personaService.selectPersonaList(persona);
        ExcelUtil<Persona> util = new ExcelUtil<Persona>(Persona.class);
        return util.exportExcel(list, "角色信息表数据");
    }

    /**
     * 新增角色信息表
     */
    @GetMapping("/add")
    public String add(ModelMap mmap)
    {
        List<Attr> attrs = attrService.selectAttrList(null);
        mmap.put("attrs", attrs);
        return prefix + "/add";
    }

    /**
     * 新增保存角色信息表
     */
    @RequiresPermissions("genshin:persona:add")
    @Log(title = "角色信息表", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(Persona persona)
    {
        return toAjax(personaService.insertPersona(persona));
    }

    /**
     * 修改角色信息表
     */
    @RequiresPermissions("genshin:persona:edit")
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Long id, ModelMap mmap)
    {
        Persona persona = personaService.selectPersonaById(id);
        mmap.put("persona", persona);
        List<Attr> attrs = attrService.selectAttrList(null);
        mmap.put("attrs", attrs);
        return prefix + "/edit";
    }

    /**
     * 修改保存角色信息表
     */
    @RequiresPermissions("genshin:persona:edit")
    @Log(title = "角色信息表", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(Persona persona)
    {
        return toAjax(personaService.updatePersona(persona));
    }

    /**
     * 删除角色信息表
     */
    @RequiresPermissions("genshin:persona:remove")
    @Log(title = "角色信息表", businessType = BusinessType.DELETE)
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(personaService.deletePersonaByIds(ids));
    }
}
