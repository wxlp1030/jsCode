package com.ruoyi.genshin.service;

import java.util.List;
import com.ruoyi.genshin.domain.Persona;

/**
 * 角色信息表Service接口
 * 
 * @author ruoyi
 * @date 2022-09-05
 */
public interface IPersonaService 
{
    /**
     * 查询角色信息表
     * 
     * @param id 角色信息表主键
     * @return 角色信息表
     */
    public Persona selectPersonaById(Long id);

    /**
     * 查询角色信息表列表
     * 
     * @param persona 角色信息表
     * @return 角色信息表集合
     */
    public List<Persona> selectPersonaList(Persona persona);

    /**
     * 新增角色信息表
     * 
     * @param persona 角色信息表
     * @return 结果
     */
    public int insertPersona(Persona persona);

    /**
     * 修改角色信息表
     * 
     * @param persona 角色信息表
     * @return 结果
     */
    public int updatePersona(Persona persona);

    /**
     * 批量删除角色信息表
     * 
     * @param ids 需要删除的角色信息表主键集合
     * @return 结果
     */
    public int deletePersonaByIds(String ids);

    /**
     * 删除角色信息表信息
     * 
     * @param id 角色信息表主键
     * @return 结果
     */
    public int deletePersonaById(Long id);
}
