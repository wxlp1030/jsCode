package com.ruoyi.genshin.mapper;

import java.util.List;
import com.ruoyi.genshin.domain.Persona;

/**
 * 角色信息表Mapper接口
 * 
 * @author ruoyi
 * @date 2022-09-05
 */
public interface PersonaMapper 
{
    /**
     * 查询角色信息表
     * 
     * @param id 角色信息表主键
     * @return 角色信息表
     */
    public Persona selectPersonaById(Long id);

    /**
     * 查询角色信息表列表
     * 
     * @param persona 角色信息表
     * @return 角色信息表集合
     */
    public List<Persona> selectPersonaList(Persona persona);

    /**
     * 新增角色信息表
     * 
     * @param persona 角色信息表
     * @return 结果
     */
    public int insertPersona(Persona persona);

    /**
     * 修改角色信息表
     * 
     * @param persona 角色信息表
     * @return 结果
     */
    public int updatePersona(Persona persona);

    /**
     * 删除角色信息表
     * 
     * @param id 角色信息表主键
     * @return 结果
     */
    public int deletePersonaById(Long id);

    /**
     * 批量删除角色信息表
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deletePersonaByIds(String[] ids);
}
