package com.ruoyi.genshin.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.genshin.mapper.PersonaMapper;
import com.ruoyi.genshin.domain.Persona;
import com.ruoyi.genshin.service.IPersonaService;
import com.ruoyi.common.core.text.Convert;

/**
 * 角色信息表Service业务层处理
 * 
 * @author ruoyi
 * @date 2022-09-05
 */
@Service
public class PersonaServiceImpl implements IPersonaService 
{
    @Autowired
    private PersonaMapper personaMapper;

    /**
     * 查询角色信息表
     * 
     * @param id 角色信息表主键
     * @return 角色信息表
     */
    @Override
    public Persona selectPersonaById(Long id)
    {
        return personaMapper.selectPersonaById(id);
    }

    /**
     * 查询角色信息表列表
     * 
     * @param persona 角色信息表
     * @return 角色信息表
     */
    @Override
    public List<Persona> selectPersonaList(Persona persona)
    {
        return personaMapper.selectPersonaList(persona);
    }

    /**
     * 新增角色信息表
     * 
     * @param persona 角色信息表
     * @return 结果
     */
    @Override
    public int insertPersona(Persona persona)
    {
        return personaMapper.insertPersona(persona);
    }

    /**
     * 修改角色信息表
     * 
     * @param persona 角色信息表
     * @return 结果
     */
    @Override
    public int updatePersona(Persona persona)
    {
        return personaMapper.updatePersona(persona);
    }

    /**
     * 批量删除角色信息表
     * 
     * @param ids 需要删除的角色信息表主键
     * @return 结果
     */
    @Override
    public int deletePersonaByIds(String ids)
    {
        return personaMapper.deletePersonaByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除角色信息表信息
     * 
     * @param id 角色信息表主键
     * @return 结果
     */
    @Override
    public int deletePersonaById(Long id)
    {
        return personaMapper.deletePersonaById(id);
    }
}
