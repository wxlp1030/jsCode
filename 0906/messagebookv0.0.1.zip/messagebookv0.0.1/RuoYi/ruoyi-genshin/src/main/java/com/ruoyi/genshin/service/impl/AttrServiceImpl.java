package com.ruoyi.genshin.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.genshin.mapper.AttrMapper;
import com.ruoyi.genshin.domain.Attr;
import com.ruoyi.genshin.service.IAttrService;
import com.ruoyi.common.core.text.Convert;

/**
 * 属性信息Service业务层处理
 * 
 * @author ruoyi
 * @date 2022-09-05
 */
@Service
public class AttrServiceImpl implements IAttrService 
{
    @Autowired
    private AttrMapper attrMapper;

    /**
     * 查询属性信息
     * 
     * @param id 属性信息主键
     * @return 属性信息
     */
    @Override
    public Attr selectAttrById(Long id)
    {
        return attrMapper.selectAttrById(id);
    }

    /**
     * 查询属性信息列表
     * 
     * @param attr 属性信息
     * @return 属性信息
     */
    @Override
    public List<Attr> selectAttrList(Attr attr)
    {
        return attrMapper.selectAttrList(attr);
    }

    /**
     * 新增属性信息
     * 
     * @param attr 属性信息
     * @return 结果
     */
    @Override
    public int insertAttr(Attr attr)
    {
        return attrMapper.insertAttr(attr);
    }

    /**
     * 修改属性信息
     * 
     * @param attr 属性信息
     * @return 结果
     */
    @Override
    public int updateAttr(Attr attr)
    {
        return attrMapper.updateAttr(attr);
    }

    /**
     * 批量删除属性信息
     * 
     * @param ids 需要删除的属性信息主键
     * @return 结果
     */
    @Override
    public int deleteAttrByIds(String ids)
    {
        return attrMapper.deleteAttrByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除属性信息信息
     * 
     * @param id 属性信息主键
     * @return 结果
     */
    @Override
    public int deleteAttrById(Long id)
    {
        return attrMapper.deleteAttrById(id);
    }
}
