package com.ruoyi.genshin.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 属性信息对象 shin_attr
 * 
 * @author ruoyi
 * @date 2022-09-05
 */
public class Attr extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 属性编号 */
    private Long id;

    /** 属性名称 */
    @Excel(name = "属性名称")
    private String name;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setName(String name) 
    {
        this.name = name;
    }

    public String getName() 
    {
        return name;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("name", getName())
            .toString();
    }
}
