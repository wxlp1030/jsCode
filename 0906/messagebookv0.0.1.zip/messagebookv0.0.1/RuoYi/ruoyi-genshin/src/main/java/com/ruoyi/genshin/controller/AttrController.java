package com.ruoyi.genshin.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.genshin.domain.Attr;
import com.ruoyi.genshin.service.IAttrService;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 属性信息Controller
 * 
 * @author ruoyi
 * @date 2022-09-05
 */
@Controller
@RequestMapping("/genshin/attr")
public class AttrController extends BaseController
{
    private String prefix = "genshin/attr";

    @Autowired
    private IAttrService attrService;

    @RequiresPermissions("genshin:attr:view")
    @GetMapping()
    public String attr()
    {
        return prefix + "/attr";
    }

    /**
     * 查询属性信息列表
     */
    @RequiresPermissions("genshin:attr:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(Attr attr)
    {
        startPage();
        List<Attr> list = attrService.selectAttrList(attr);
        return getDataTable(list);
    }

    /**
     * 导出属性信息列表
     */
    @RequiresPermissions("genshin:attr:export")
    @Log(title = "属性信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(Attr attr)
    {
        List<Attr> list = attrService.selectAttrList(attr);
        ExcelUtil<Attr> util = new ExcelUtil<Attr>(Attr.class);
        return util.exportExcel(list, "属性信息数据");
    }

    /**
     * 新增属性信息
     */
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    /**
     * 新增保存属性信息
     */
    @RequiresPermissions("genshin:attr:add")
    @Log(title = "属性信息", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(Attr attr)
    {
        return toAjax(attrService.insertAttr(attr));
    }

    /**
     * 修改属性信息
     */
    @RequiresPermissions("genshin:attr:edit")
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Long id, ModelMap mmap)
    {
        Attr attr = attrService.selectAttrById(id);
        mmap.put("attr", attr);
        return prefix + "/edit";
    }

    /**
     * 修改保存属性信息
     */
    @RequiresPermissions("genshin:attr:edit")
    @Log(title = "属性信息", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(Attr attr)
    {
        return toAjax(attrService.updateAttr(attr));
    }

    /**
     * 删除属性信息
     */
    @RequiresPermissions("genshin:attr:remove")
    @Log(title = "属性信息", businessType = BusinessType.DELETE)
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(attrService.deleteAttrByIds(ids));
    }
}
