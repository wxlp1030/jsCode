package com.ruoyi.kaifamiao.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.kaifamiao.mapper.KfmMapper;
import com.ruoyi.kaifamiao.domain.Kfm;
import com.ruoyi.kaifamiao.service.IKfmService;
import com.ruoyi.common.core.text.Convert;

/**
 * kfmService业务层处理
 * 
 * @author ruoyi
 * @date 2022-09-05
 */
@Service
public class KfmServiceImpl implements IKfmService 
{
    @Autowired
    private KfmMapper kfmMapper;

    /**
     * 查询kfm
     * 
     * @param id kfm主键
     * @return kfm
     */
    @Override
    public Kfm selectKfmById(Long id)
    {
        return kfmMapper.selectKfmById(id);
    }

    /**
     * 查询kfm列表
     * 
     * @param kfm kfm
     * @return kfm
     */
    @Override
    public List<Kfm> selectKfmList(Kfm kfm)
    {
        return kfmMapper.selectKfmList(kfm);
    }

    /**
     * 新增kfm
     * 
     * @param kfm kfm
     * @return 结果
     */
    @Override
    public int insertKfm(Kfm kfm)
    {
        return kfmMapper.insertKfm(kfm);
    }

    /**
     * 修改kfm
     * 
     * @param kfm kfm
     * @return 结果
     */
    @Override
    public int updateKfm(Kfm kfm)
    {
        return kfmMapper.updateKfm(kfm);
    }

    /**
     * 批量删除kfm
     * 
     * @param ids 需要删除的kfm主键
     * @return 结果
     */
    @Override
    public int deleteKfmByIds(String ids)
    {
        return kfmMapper.deleteKfmByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除kfm信息
     * 
     * @param id kfm主键
     * @return 结果
     */
    @Override
    public int deleteKfmById(Long id)
    {
        return kfmMapper.deleteKfmById(id);
    }
}
