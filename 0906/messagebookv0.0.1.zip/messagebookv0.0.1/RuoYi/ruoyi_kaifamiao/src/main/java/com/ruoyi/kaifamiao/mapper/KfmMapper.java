package com.ruoyi.kaifamiao.mapper;

import java.util.List;
import com.ruoyi.kaifamiao.domain.Kfm;

/**
 * kfmMapper接口
 * 
 * @author ruoyi
 * @date 2022-09-05
 */
public interface KfmMapper 
{
    /**
     * 查询kfm
     * 
     * @param id kfm主键
     * @return kfm
     */
    public Kfm selectKfmById(Long id);

    /**
     * 查询kfm列表
     * 
     * @param kfm kfm
     * @return kfm集合
     */
    public List<Kfm> selectKfmList(Kfm kfm);

    /**
     * 新增kfm
     * 
     * @param kfm kfm
     * @return 结果
     */
    public int insertKfm(Kfm kfm);

    /**
     * 修改kfm
     * 
     * @param kfm kfm
     * @return 结果
     */
    public int updateKfm(Kfm kfm);

    /**
     * 删除kfm
     * 
     * @param id kfm主键
     * @return 结果
     */
    public int deleteKfmById(Long id);

    /**
     * 批量删除kfm
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteKfmByIds(String[] ids);
}
