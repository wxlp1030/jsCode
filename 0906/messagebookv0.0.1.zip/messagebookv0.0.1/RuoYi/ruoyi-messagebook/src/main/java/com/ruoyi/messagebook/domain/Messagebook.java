package com.ruoyi.messagebook.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 留言信息对象 messagebook
 * 
 * @author ruoyi
 * @date 2022-09-06
 */
public class Messagebook extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 留言id */
    private Long messageid;

    /** 用户id */
    @Excel(name = "用户id")
    private Long userid;

    /** 留言时间 */
    @Excel(name = "留言时间")
    private String createDatetime;

    /** 留言ip */
    @Excel(name = "留言ip")
    private String ip;

    /** 留言标题 */
    @Excel(name = "留言标题")
    private String title;

    /** 留言板块 */
    @Excel(name = "留言板块")
    private String plate;

    /** 表情 */
    @Excel(name = "表情")
    private String emotion;

    /** 内容 */
    @Excel(name = "内容")
    private String text;

    /** 附件 */
    @Excel(name = "附件")
    private String newspaper;

    public void setMessageid(Long messageid) 
    {
        this.messageid = messageid;
    }

    public Long getMessageid() 
    {
        return messageid;
    }
    public void setUserid(Long userid) 
    {
        this.userid = userid;
    }

    public Long getUserid() 
    {
        return userid;
    }
    public void setCreateDatetime(String createDatetime) 
    {
        this.createDatetime = createDatetime;
    }

    public String getCreateDatetime() 
    {
        return createDatetime;
    }
    public void setIp(String ip) 
    {
        this.ip = ip;
    }

    public String getIp() 
    {
        return ip;
    }
    public void setTitle(String title) 
    {
        this.title = title;
    }

    public String getTitle() 
    {
        return title;
    }
    public void setPlate(String plate) 
    {
        this.plate = plate;
    }

    public String getPlate() 
    {
        return plate;
    }
    public void setEmotion(String emotion) 
    {
        this.emotion = emotion;
    }

    public String getEmotion() 
    {
        return emotion;
    }
    public void setText(String text) 
    {
        this.text = text;
    }

    public String getText() 
    {
        return text;
    }
    public void setNewspaper(String newspaper) 
    {
        this.newspaper = newspaper;
    }

    public String getNewspaper() 
    {
        return newspaper;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("messageid", getMessageid())
            .append("userid", getUserid())
            .append("createDatetime", getCreateDatetime())
            .append("ip", getIp())
            .append("title", getTitle())
            .append("plate", getPlate())
            .append("emotion", getEmotion())
            .append("text", getText())
            .append("newspaper", getNewspaper())
            .toString();
    }
}
