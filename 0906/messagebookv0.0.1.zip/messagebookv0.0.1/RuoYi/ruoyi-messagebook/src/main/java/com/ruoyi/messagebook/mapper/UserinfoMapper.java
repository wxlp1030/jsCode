package com.ruoyi.messagebook.mapper;

import java.util.List;
import com.ruoyi.messagebook.domain.Userinfo;

/**
 * 用户管理Mapper接口
 * 
 * @author kfmxh
 * @date 2022-09-06
 */
public interface UserinfoMapper 
{
    /**
     * 查询用户管理
     * 
     * @param userid 用户管理主键
     * @return 用户管理
     */
    public Userinfo selectUserinfoByUserid(Long userid);

    /**
     * 查询用户管理列表
     * 
     * @param userinfo 用户管理
     * @return 用户管理集合
     */
    public List<Userinfo> selectUserinfoList(Userinfo userinfo);

    public Userinfo selectUserinfoLogin(Userinfo userinfo);

    /**
     * 新增用户管理
     * 
     * @param userinfo 用户管理
     * @return 结果
     */
    public int insertUserinfo(Userinfo userinfo);

    /**
     * 修改用户管理
     * 
     * @param userinfo 用户管理
     * @return 结果
     */
    public int updateUserinfo(Userinfo userinfo);

    /**
     * 删除用户管理
     * 
     * @param userid 用户管理主键
     * @return 结果
     */
    public int deleteUserinfoByUserid(Long userid);

    /**
     * 批量删除用户管理
     * 
     * @param userids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteUserinfoByUserids(String[] userids);
}
