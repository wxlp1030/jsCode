package com.ruoyi.messagebook.mapper;

import java.util.List;
import com.ruoyi.messagebook.domain.Banner;

/**
 * 广告管理Mapper接口
 * 
 * @author ruoyi
 * @date 2022-09-06
 */
public interface BannerMapper 
{
    /**
     * 查询广告管理
     * 
     * @param id 广告管理主键
     * @return 广告管理
     */
    public Banner selectBannerById(Long id);

    /**
     * 查询广告管理列表
     * 
     * @param banner 广告管理
     * @return 广告管理集合
     */
    public List<Banner> selectBannerList(Banner banner);

    /**
     * 新增广告管理
     * 
     * @param banner 广告管理
     * @return 结果
     */
    public int insertBanner(Banner banner);

    /**
     * 修改广告管理
     * 
     * @param banner 广告管理
     * @return 结果
     */
    public int updateBanner(Banner banner);

    /**
     * 删除广告管理
     * 
     * @param id 广告管理主键
     * @return 结果
     */
    public int deleteBannerById(Long id);

    /**
     * 批量删除广告管理
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteBannerByIds(String[] ids);
}
