package com.ruoyi.messagebook.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.messagebook.mapper.MessagebookMapper;
import com.ruoyi.messagebook.domain.Messagebook;
import com.ruoyi.messagebook.service.IMessagebookService;
import com.ruoyi.common.core.text.Convert;

/**
 * 留言信息Service业务层处理
 * 
 * @author ruoyi
 * @date 2022-09-06
 */
@Service
public class MessagebookServiceImpl implements IMessagebookService 
{
    @Autowired
    private MessagebookMapper messagebookMapper;

    /**
     * 查询留言信息
     * 
     * @param messageid 留言信息主键
     * @return 留言信息
     */
    @Override
    public Messagebook selectMessagebookByMessageid(Long messageid)
    {
        return messagebookMapper.selectMessagebookByMessageid(messageid);
    }

    /**
     * 查询留言信息列表
     * 
     * @param messagebook 留言信息
     * @return 留言信息
     */
    @Override
    public List<Messagebook> selectMessagebookList(Messagebook messagebook)
    {
        return messagebookMapper.selectMessagebookList(messagebook);
    }

    /**
     * 新增留言信息
     * 
     * @param messagebook 留言信息
     * @return 结果
     */
    @Override
    public int insertMessagebook(Messagebook messagebook)
    {
        return messagebookMapper.insertMessagebook(messagebook);
    }

    /**
     * 修改留言信息
     * 
     * @param messagebook 留言信息
     * @return 结果
     */
    @Override
    public int updateMessagebook(Messagebook messagebook)
    {
        return messagebookMapper.updateMessagebook(messagebook);
    }

    /**
     * 批量删除留言信息
     * 
     * @param messageids 需要删除的留言信息主键
     * @return 结果
     */
    @Override
    public int deleteMessagebookByMessageids(String messageids)
    {
        return messagebookMapper.deleteMessagebookByMessageids(Convert.toStrArray(messageids));
    }

    /**
     * 删除留言信息信息
     * 
     * @param messageid 留言信息主键
     * @return 结果
     */
    @Override
    public int deleteMessagebookByMessageid(Long messageid)
    {
        return messagebookMapper.deleteMessagebookByMessageid(messageid);
    }
}
