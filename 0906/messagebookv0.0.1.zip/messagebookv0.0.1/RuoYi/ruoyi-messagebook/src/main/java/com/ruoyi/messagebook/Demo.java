package com.ruoyi.messagebook;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;

public class Demo {
    public static void main(String[] args) {


        String format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        System.out.println(format);
    }
}
