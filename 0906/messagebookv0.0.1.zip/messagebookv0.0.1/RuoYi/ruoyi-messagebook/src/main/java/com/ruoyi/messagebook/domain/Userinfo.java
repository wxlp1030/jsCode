package com.ruoyi.messagebook.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 用户管理对象 userinfo
 * 
 * @author kfmxh
 * @date 2022-09-06
 */
public class Userinfo extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 用户ID */
    private Long userid;

    /** 用户名 */
    @Excel(name = "用户名")
    private String username;

    /** 密码 */
    @Excel(name = "密码")
    private String password;

    /** 注册时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "注册时间", width = 30, dateFormat = "yyyy-MM-dd hh:mm:ss")
    private Date regDatetime;

    /** 角色 */
    @Excel(name = "角色")
    private Long role;

    /** 注册IP */
    @Excel(name = "注册IP")
    private String regIp;

    /** 手机号 */
    @Excel(name = "手机号")
    private String mobile;

    /** 性别 */
    @Excel(name = "性别")
    private Long sex;

    /** 是否激活 */
    @Excel(name = "是否激活")
    private Long isActive;

    /** 是否是会员 */
    @Excel(name = "是否是会员")
    private Long isVip;

    public void setUserid(Long userid) 
    {
        this.userid = userid;
    }

    public Long getUserid() 
    {
        return userid;
    }
    public void setUsername(String username) 
    {
        this.username = username;
    }

    public String getUsername() 
    {
        return username;
    }
    public void setPassword(String password) 
    {
        this.password = password;
    }

    public String getPassword() 
    {
        return password;
    }
    public void setRegDatetime(Date regDatetime) 
    {
        this.regDatetime = regDatetime;
    }

    public Date getRegDatetime() 
    {
        return regDatetime;
    }
    public void setRole(Long role) 
    {
        this.role = role;
    }

    public Long getRole() 
    {
        return role;
    }
    public void setRegIp(String regIp) 
    {
        this.regIp = regIp;
    }

    public String getRegIp() 
    {
        return regIp;
    }
    public void setMobile(String mobile) 
    {
        this.mobile = mobile;
    }

    public String getMobile() 
    {
        return mobile;
    }
    public void setSex(Long sex) 
    {
        this.sex = sex;
    }

    public Long getSex() 
    {
        return sex;
    }
    public void setIsActive(Long isActive) 
    {
        this.isActive = isActive;
    }

    public Long getIsActive() 
    {
        return isActive;
    }
    public void setIsVip(Long isVip) 
    {
        this.isVip = isVip;
    }

    public Long getIsVip() 
    {
        return isVip;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("userid", getUserid())
            .append("username", getUsername())
            .append("password", getPassword())
            .append("regDatetime", getRegDatetime())
            .append("role", getRole())
            .append("regIp", getRegIp())
            .append("mobile", getMobile())
            .append("sex", getSex())
            .append("isActive", getIsActive())
            .append("isVip", getIsVip())
            .toString();
    }
}
