package com.ruoyi.messagebook.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ruoyi.common.utils.spring.SpringUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.messagebook.domain.Messagebook;
import com.ruoyi.messagebook.service.IMessagebookService;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

import javax.servlet.http.HttpServletRequest;

/**
 * 留言信息Controller
 * 
 * @author ruoyi
 * @date 2022-09-06
 */
@Api("messagebook")
@Controller
@RequestMapping("/messagebook/messagebook")
public class MessagebookController extends BaseController
{
    private String prefix = "messagebook/messagebook";

    @Autowired
    private IMessagebookService messagebookService;

//    @RequiresPermissions("messagebook:messagebook:view")
    @GetMapping()
    public String messagebook()
    {
        return prefix + "/messagebook";
    }

    /**
     * 查询留言信息列表
     */
    @ApiOperation("查询列表")
//    @RequiresPermissions("messagebook:messagebook:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(Messagebook messagebook)
    {
        startPage();
        List<Messagebook> list = messagebookService.selectMessagebookList(messagebook);
        return getDataTable(list);
    }


    @GetMapping("/list")
    @ResponseBody
    public AjaxResult lists() {
        List<Messagebook> list = messagebookService.selectMessagebookList(null);
        return AjaxResult.success("查询成功", list);
    }

    @ApiOperation("查询单个")
    @GetMapping("/list/{id}")
    @ResponseBody
    public AjaxResult selectById(@PathVariable Long id)
    {
        startPage();
        Messagebook messagebook = messagebookService.selectMessagebookByMessageid(id);
        if (messagebook != null) {
            return AjaxResult.success("请求成功", messagebook) ;
        }
        return AjaxResult.error("请求失败！");
    }

    /**
     * 导出留言信息列表
     */
    @ApiOperation("导出留言信息列表")
//    @RequiresPermissions("messagebook:messagebook:export")
    @Log(title = "留言信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(Messagebook messagebook)
    {
        List<Messagebook> list = messagebookService.selectMessagebookList(messagebook);
        ExcelUtil<Messagebook> util = new ExcelUtil<Messagebook>(Messagebook.class);
        return util.exportExcel(list, "留言信息数据");
    }



    /**
     * 新增留言信息
     */
    @ApiOperation("新增留言信息")
    @GetMapping("/add")
    public String add(ModelMap modelMap, Long userid)
    {
        String[] plates = {"问题反馈", "吐槽", "抒发情绪", "紧急事件"};
        modelMap.put("plates", plates);
        String[] images = {"001.png", "002.png", "003.png", "004.png", "005.png", "006.png"};
        modelMap.put("images", images);
        if (userid == null) {
            userid = 1L; // 测试数据
        }
        modelMap.put("userid", userid);
        return prefix + "/add";
    }

    /**
     * 新增保存留言信息
     */
    @ApiOperation("新增保存留言信息")
//    @RequiresPermissions("messagebook:messagebook:add")
    @Log(title = "留言信息", businessType = BusinessType.INSERT)
    @PostMapping("/add1")
    @ResponseBody
    public AjaxResult addSave(@RequestBody Messagebook messagebook, HttpServletRequest request)
    {
        messagebook.setCreateDatetime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
        messagebook.setIp(request.getRemoteAddr());
        return toAjax(messagebookService.insertMessagebook(messagebook));
    }

    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave1(Messagebook messagebook, HttpServletRequest request)
    {
        messagebook.setCreateDatetime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
        messagebook.setIp(request.getRemoteAddr());
        return toAjax(messagebookService.insertMessagebook(messagebook));
    }

    /**
     * 修改留言信息
     */
    @ApiOperation("修改留言信息")
//    @RequiresPermissions("messagebook:messagebook:edit")
    @GetMapping("/edit/{messageid}")
    public String edit(@PathVariable("messageid") Long messageid, ModelMap mmap)
    {
        Messagebook messagebook = messagebookService.selectMessagebookByMessageid(messageid);
        mmap.put("messagebook", messagebook);
        String[] plates = {"问题反馈", "吐槽", "抒发情绪", "紧急事件"};
        mmap.put("plates", plates);
        String[] images = {"001.png", "002.png", "003.png", "004.png", "005.png", "006.png"};
        mmap.put("images", images);
        return prefix + "/edit";
    }

    /**
     * 修改保存留言信息
     */
    @ApiOperation("修改保存留言信息")
//    @RequiresPermissions("messagebook:messagebook:edit")
    @Log(title = "留言信息", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(Messagebook messagebook)
    {
        return toAjax(messagebookService.updateMessagebook(messagebook));
    }

    @ApiOperation("修改保存留言信息")
//    @RequiresPermissions("messagebook:messagebook:edit")
    @Log(title = "留言信息", businessType = BusinessType.UPDATE)
    @PostMapping("/edit1")
    @ResponseBody
    public AjaxResult editSave1(@RequestBody  Messagebook messagebook)
    {
        return toAjax(messagebookService.updateMessagebook(messagebook));
    }

    /**
     * 删除留言信息
     */
    @ApiOperation("删除留言信息")
//    @RequiresPermissions("messagebook:messagebook:remove")
    @Log(title = "留言信息", businessType = BusinessType.DELETE)
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(messagebookService.deleteMessagebookByMessageids(ids));
    }

    @ApiOperation("获取留言板块以及表情信息")
    @GetMapping("/data")
    @ResponseBody
    public AjaxResult getData() {
        String[] plates = {"问题反馈", "吐槽", "抒发情绪", "紧急事件"};
        String[] emotions = {"001.png", "002.png", "003.png", "004.png", "005.png", "006.png"};
        Map<String, Object> map = new HashMap<>();
        map.put("plates", plates);
        map.put("emotions", emotions);
        return AjaxResult.success("请求成功", map);
    }
}
