package com.ruoyi.messagebook.controller;


import java.util.List;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.commons.collections.CollectionUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.messagebook.domain.Userinfo;
import com.ruoyi.messagebook.service.IUserinfoService;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

import javax.servlet.http.HttpServletRequest;

/**
 * 用户管理Controller
 * 
 * @author kfmxh
 * @date 2022-09-06
 */
@Api("用户信息管理")
@Controller
@RequestMapping("/messagebook/userinfo")
public class UserinfoController extends BaseController
{
    private String prefix = "messagebook/userinfo";

    @Autowired
    private IUserinfoService userinfoService;

//    @RequiresPermissions("messagebook:userinfo:view")
    @GetMapping()
    public String userinfo()
    {
        return prefix + "/userinfo";
    }

    /**
     * 查询用户管理列表
     */
    @ApiOperation("用户列表")
//    @RequiresPermissions("messagebook:userinfo:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(Userinfo userinfo)
    {
        startPage();
        List<Userinfo> list = userinfoService.selectUserinfoList(userinfo);
        return getDataTable(list);
    }

    @ApiOperation("登录")
    @PostMapping("/login")
    @ResponseBody
    public AjaxResult login(@RequestBody Userinfo userinfo){
        System.out.println(userinfo);
        if(ObjectUtils.isEmpty(userinfo.getUsername())){
            return AjaxResult.error("default");
        }
        if(ObjectUtils.isEmpty(userinfo.getPassword())){
            return AjaxResult.error("default");
        }
        Userinfo userinfo1 = userinfoService.selectUserinfoLogin(userinfo);
        return  ObjectUtils.isEmpty(userinfo1) ? AjaxResult.error("default"): AjaxResult.success("successful",userinfo1);
    }

    /**
     * 导出用户管理列表
     */
//    @RequiresPermissions("messagebook:userinfo:export")
    @Log(title = "用户管理", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(Userinfo userinfo)
    {
        List<Userinfo> list = userinfoService.selectUserinfoList(userinfo);
        ExcelUtil<Userinfo> util = new ExcelUtil<Userinfo>(Userinfo.class);
        return util.exportExcel(list, "用户管理数据");
    }

    /**
     * 新增用户管理
     */
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    /**
     * 新增保存用户管理
     */
    @ApiOperation("注册")
//    @RequiresPermissions("messagebook:userinfo:add")
    @PostMapping("/save")
    @ResponseBody
    public AjaxResult Save(@RequestBody Userinfo userinfo, HttpServletRequest request)
    {
        userinfo.setRegIp(getIp(request));
        return toAjax(userinfoService.insertUserinfo(userinfo));
    }


    @Log(title = "用户管理", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(Userinfo userinfo, HttpServletRequest request)
    {
        System.out.println(userinfo.toString());
        userinfo.setRegIp(getIp(request));
        return toAjax(userinfoService.insertUserinfo(userinfo));
    }

    /**
     * 修改用户管理
     */
//    @RequiresPermissions("messagebook:userinfo:edit")
    @GetMapping("/edit/{userid}")
    public String edit(@PathVariable("userid") Long userid, ModelMap mmap)
    {
        Userinfo userinfo = userinfoService.selectUserinfoByUserid(userid);
        mmap.put("userinfo", userinfo);
        return prefix + "/edit";
    }

    /**
     * 修改保存用户管理
     */
//    @RequiresPermissions("messagebook:userinfo:edit")
    @Log(title = "用户管理", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(Userinfo userinfo)
    {
        return toAjax(userinfoService.updateUserinfo(userinfo));
    }

    /**
     * 删除用户管理
     */
//    @RequiresPermissions("messagebook:userinfo:remove")
    @Log(title = "用户管理", businessType = BusinessType.DELETE)
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(userinfoService.deleteUserinfoByUserids(ids));
    }

    /**
     * 获取客户端ip
     * @return
     */
    protected String getIp(HttpServletRequest request) {
        String ip = request.getHeader("x-forwarded-for");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        return ip.trim().equals("0:0:0:0:0:0:0:1") ? "127.0.0.1" : ip;
    }
}
