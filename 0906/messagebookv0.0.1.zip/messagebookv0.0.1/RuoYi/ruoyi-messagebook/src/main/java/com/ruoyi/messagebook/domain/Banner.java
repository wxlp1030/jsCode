package com.ruoyi.messagebook.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 广告管理对象 banner
 * 
 * @author ruoyi
 * @date 2022-09-06
 */
public class Banner extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** id */
    private Long id;

    /** 图片路径 */
    @Excel(name = "图片路径")
    private String imgUrl;

    /** 图片链接 */
    @Excel(name = "图片链接")
    private String link;

    /** 显示文字 */
    @Excel(name = "显示文字")
    private String text;

    /** 创建时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date createDate;

    /** 开始时间 */
    @Excel(name = "开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date startDate;

    /** 结束时间 */
    @Excel(name = "结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date endDate;

    /** 是否付费 */
    @Excel(name = "是否付费")
    private String ispay;

    /** 点击次数 */
    @Excel(name = "点击次数")
    private Long clickCount;

    /** 展示次数 */
    @Excel(name = "展示次数")
    private Long showCount;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setImgUrl(String imgUrl) 
    {
        this.imgUrl = imgUrl;
    }

    public String getImgUrl() 
    {
        return imgUrl;
    }
    public void setLink(String link) 
    {
        this.link = link;
    }

    public String getLink() 
    {
        return link;
    }
    public void setText(String text) 
    {
        this.text = text;
    }

    public String getText() 
    {
        return text;
    }

    public void setCreateDate(Date createDate)
    {
        this.createDate = createDate;
    }

    public Date getCreateDate()
    {
        return createDate;
    }
    public void setStartDate(Date startDate)
    {
        this.startDate = startDate;
    }

    public Date getStartDate()
    {
        return startDate;
    }
    public void setEndDate(Date endDate)
    {
        this.endDate = endDate;
    }

    public Date getEndDate()
    {
        return endDate;
    }
    public void setIspay(String ispay) 
    {
        this.ispay = ispay;
    }

    public String getIspay() 
    {
        return ispay;
    }

    public void setClickCount(Long clickCount)
    {
        this.clickCount = clickCount;
    }

    public Long getClickCount() 
    {
        return clickCount;
    }
    public void setShowCount(Long showCount) 
    {
        this.showCount = showCount;
    }

    public Long getShowCount() 
    {
        return showCount;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("imgUrl", getImgUrl())
            .append("link", getLink())
            .append("text", getText())
            .append("createDate", getCreateDate())
            .append("startDate", getStartDate())
            .append("endDate", getEndDate())
            .append("ispay", getIspay())
            .append("clickCount", getClickCount())
            .append("showCount", getShowCount())
            .toString();
    }
}
