package com.ruoyi.messagebook.controller;

import java.util.List;

import io.swagger.annotations.*;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.messagebook.domain.Banner;
import com.ruoyi.messagebook.service.IBannerService;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 广告管理Controller
 * 
 * @author ruoyi
 * @date 2022-09-06
 */
@Api("广告管理接口")
@Controller
@RequestMapping("/messagebook/banner")
public class BannerController extends BaseController
{
    private String prefix = "messagebook/banner";

    @Autowired
    private IBannerService bannerService;

    @RequiresPermissions("messagebook:banner:view")
    @GetMapping()
    public String banner()
    {
        return prefix + "/banner";
    }

    /**
     * 查询广告管理列表
     */
//    @RequiresPermissions("messagebook:banner:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(Banner banner)
    {
        startPage();
        List<Banner> list = bannerService.selectBannerList(banner);
        return getDataTable(list);
    }

    @ApiOperation("获取广告列表")
    @GetMapping("/list")
    @ResponseBody
    public TableDataInfo list1()
    {
        startPage();
        List<Banner> list = bannerService.selectBannerList(null);
        for(Banner banner : list){
            banner.setShowCount(banner.getShowCount() + 1);
            bannerService.updateBanner(banner);
        }
        return getDataTable(list);
    }

    @ApiOperation("获取详细广告列表")
    @GetMapping("/list/{id}")
    @ResponseBody
    public Banner listById(@PathVariable Long id)
    {
        return bannerService.selectBannerById(id);
    }

    @ApiOperation("获取点击次数")
    @GetMapping("/edit1/{id}")
    @ResponseBody
    public AjaxResult isClickCount(@PathVariable Long id){
        Banner banner = bannerService.selectBannerById(id);
        banner.setClickCount(banner.getClickCount() + 1);
        return toAjax(bannerService.updateBanner(banner));
    }

    /**
     * 导出广告管理列表
     */
//    @RequiresPermissions("messagebook:banner:export")
    @Log(title = "广告管理", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(Banner banner)
    {
        List<Banner> list = bannerService.selectBannerList(banner);
        ExcelUtil<Banner> util = new ExcelUtil<Banner>(Banner.class);
        return util.exportExcel(list, "广告管理数据");
    }

    /**
     * 新增广告管理
     */
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    /**
     * 新增保存广告管理
     */
//    @RequiresPermissions("messagebook:banner:add")
    @ApiOperation("新增广告")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "id", dataType = "Integer", dataTypeClass = Integer.class),
            @ApiImplicitParam(name = "imgUrl", value = "图片路径", dataType = "String", dataTypeClass = String.class),
            @ApiImplicitParam(name = "link", value = "图片链接", dataType = "String", dataTypeClass = String.class),
            @ApiImplicitParam(name = "text", value = "显示内容", dataType = "String", dataTypeClass = String.class),
            @ApiImplicitParam(name = "createDate", value = "创建时间", dataType = "String", dataTypeClass = String.class),
            @ApiImplicitParam(name = "startDate", value = "开始时间", dataType = "String", dataTypeClass = String.class),
            @ApiImplicitParam(name = "endDate", value = "结束时间", dataType = "String", dataTypeClass = String.class)
    })
    @Log(title = "广告管理", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(Banner banner)
    {
        return toAjax(bannerService.insertBanner(banner));
    }

    /**
     * 修改广告管理
     */
//    @RequiresPermissions("messagebook:banner:edit")
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Long id, ModelMap mmap)
    {
        Banner banner = bannerService.selectBannerById(id);
        mmap.put("banner", banner);
        return prefix + "/edit";
    }

    /**
     * 修改保存广告管理
     */
//    @RequiresPermissions("messagebook:banner:edit")
    @Log(title = "广告管理", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(Banner banner)
    {
        return toAjax(bannerService.updateBanner(banner));
    }

    @ApiOperation("更新广告")
    @Log(title = "广告管理", businessType = BusinessType.UPDATE)
    @GetMapping("/edit")
    @ResponseBody
    public AjaxResult editSave1(Banner banner)
    {
        return toAjax(bannerService.updateBanner(banner));
    }

    /**
     * 删除广告管理
     */
//    @RequiresPermissions("messagebook:banner:remove")
    @Log(title = "广告管理", businessType = BusinessType.DELETE)
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(bannerService.deleteBannerByIds(ids));
    }

    @ApiOperation("删除广告")
    @ApiImplicitParam(name = "id", value = "id", required = true, dataType = "int", paramType = "path", dataTypeClass = Integer.class)
    @Log(title = "广告管理", businessType = BusinessType.DELETE)
    @GetMapping( "/remove")
    @ResponseBody
    public AjaxResult remove1(String ids)
    {
        return toAjax(bannerService.deleteBannerByIds(ids));
    }
}
