package com.ruoyi.messagebook.service.impl;

import java.util.List;

import com.ruoyi.common.core.domain.AjaxResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.messagebook.mapper.UserinfoMapper;
import com.ruoyi.messagebook.domain.Userinfo;
import com.ruoyi.messagebook.service.IUserinfoService;
import com.ruoyi.common.core.text.Convert;

/**
 * 用户管理Service业务层处理
 * 
 * @author kfmxh
 * @date 2022-09-06
 */
@Service
public class UserinfoServiceImpl implements IUserinfoService 
{
    @Autowired
    private UserinfoMapper userinfoMapper;

    /**
     * 查询用户管理
     * 
     * @param userid 用户管理主键
     * @return 用户管理
     */
    @Override
    public Userinfo selectUserinfoByUserid(Long userid)
    {
        return userinfoMapper.selectUserinfoByUserid(userid);
    }

    /**
     * 查询用户管理列表
     * 
     * @param userinfo 用户管理
     * @return 用户管理
     */
    @Override
    public List<Userinfo> selectUserinfoList(Userinfo userinfo)
    {
        return userinfoMapper.selectUserinfoList(userinfo);
    }

    @Override
    public Userinfo selectUserinfoLogin(Userinfo userinfo) {
        return userinfoMapper.selectUserinfoLogin(userinfo);
    }

    /**
     * 新增用户管理
     * 
     * @param userinfo 用户管理
     * @return 结果
     */
    @Override
    public int insertUserinfo(Userinfo userinfo)
    {
        return userinfoMapper.insertUserinfo(userinfo);
    }

    /**
     * 修改用户管理
     * 
     * @param userinfo 用户管理
     * @return 结果
     */
    @Override
    public int updateUserinfo(Userinfo userinfo)
    {
        return userinfoMapper.updateUserinfo(userinfo);
    }

    /**
     * 批量删除用户管理
     * 
     * @param userids 需要删除的用户管理主键
     * @return 结果
     */
    @Override
    public int deleteUserinfoByUserids(String userids)
    {
        return userinfoMapper.deleteUserinfoByUserids(Convert.toStrArray(userids));
    }

    /**
     * 删除用户管理信息
     * 
     * @param userid 用户管理主键
     * @return 结果
     */
    @Override
    public int deleteUserinfoByUserid(Long userid)
    {
        return userinfoMapper.deleteUserinfoByUserid(userid);
    }

}
