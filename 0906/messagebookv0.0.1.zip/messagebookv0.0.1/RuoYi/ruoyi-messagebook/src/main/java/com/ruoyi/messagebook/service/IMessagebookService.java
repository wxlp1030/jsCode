package com.ruoyi.messagebook.service;

import java.util.List;
import com.ruoyi.messagebook.domain.Messagebook;

/**
 * 留言信息Service接口
 * 
 * @author ruoyi
 * @date 2022-09-06
 */
public interface IMessagebookService 
{
    /**
     * 查询留言信息
     * 
     * @param messageid 留言信息主键
     * @return 留言信息
     */
    public Messagebook selectMessagebookByMessageid(Long messageid);

    /**
     * 查询留言信息列表
     * 
     * @param messagebook 留言信息
     * @return 留言信息集合
     */
    public List<Messagebook> selectMessagebookList(Messagebook messagebook);

    /**
     * 新增留言信息
     * 
     * @param messagebook 留言信息
     * @return 结果
     */
    public int insertMessagebook(Messagebook messagebook);

    /**
     * 修改留言信息
     * 
     * @param messagebook 留言信息
     * @return 结果
     */
    public int updateMessagebook(Messagebook messagebook);

    /**
     * 批量删除留言信息
     * 
     * @param messageids 需要删除的留言信息主键集合
     * @return 结果
     */
    public int deleteMessagebookByMessageids(String messageids);

    /**
     * 删除留言信息信息
     * 
     * @param messageid 留言信息主键
     * @return 结果
     */
    public int deleteMessagebookByMessageid(Long messageid);
}
