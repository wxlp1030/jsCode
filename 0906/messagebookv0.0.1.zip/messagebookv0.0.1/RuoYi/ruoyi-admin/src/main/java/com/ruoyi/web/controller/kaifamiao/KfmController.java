package com.ruoyi.web.controller.kaifamiao;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.kaifamiao.domain.Kfm;
import com.ruoyi.kaifamiao.service.IKfmService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * kfmController
 * 
 * @author ruoyi
 * @date 2022-09-05
 */
@Api("kfm")
@Controller
@RequestMapping("/kaifamiao/kfm")
public class KfmController extends BaseController
{
    private String prefix = "kaifamiao/kfm";

    @Autowired
    private IKfmService kfmService;

//    @RequiresPermissions("kaifamiao:kfm:view")
    @GetMapping()
    public String kfm()
    {
        return prefix + "/kfm";
    }

    /**
     * 查询kfm列表
     */
//    @RequiresPermissions("kaifamiao:kfm:list")
    @ApiOperation("查询列表")
    @PostMapping ("/list")
    @ApiParam(value = "查询用户列表", required = true)
    @ResponseBody
    public TableDataInfo list(Kfm kfm)
    {
        startPage();
        List<Kfm> list = kfmService.selectKfmList(kfm);
        return getDataTable(list);
    }

//    @RequiresPermissions("kaifamiao:kfm:list")
    @ApiOperation("查询单个")
    @GetMapping("/list/{userId}")
    @ResponseBody
    public Kfm listById(@PathVariable Long userId)
    {
        startPage();
        return kfmService.selectKfmById(userId);
    }

    /**
     * 导出kfm列表
     */
    @ApiOperation("导出kfm列表")
    @RequiresPermissions("kaifamiao:kfm:export")
    @Log(title = "kfm", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(Kfm kfm)
    {
        List<Kfm> list = kfmService.selectKfmList(kfm);
        ExcelUtil<Kfm> util = new ExcelUtil<Kfm>(Kfm.class);
        return util.exportExcel(list, "kfm数据");
    }

    /**
     * 新增kfm
     */
//    @ApiOperation("新增kfm")
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    @GetMapping("/index")
    public String to_index(ModelMap mmap)
    {
        mmap.put("index", list(null).getRows());
        return prefix + "/index";
    }

    /**
     * 新增保存kfm
     */
    @ApiOperation("新增kfm")
//    @RequiresPermissions("kaifamiao:kfm:add")
    @Log(title = "kfm", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(@RequestBody Kfm kfm)
    {
        return toAjax(kfmService.insertKfm(kfm));
    }

    /**
     * 修改kfm
     */
//    @RequiresPermissions("kaifamiao:kfm:edit")
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Long id, ModelMap mmap)
    {
        Kfm kfm = kfmService.selectKfmById(id);
        mmap.put("kfm", kfm);
        return prefix + "/edit";
    }

    /**
     * 修改保存kfm
     */
    @ApiOperation("修改kfm")
//    @RequiresPermissions("kaifamiao:kfm:edit")
    @Log(title = "kfm", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(Kfm kfm)
    {
        return toAjax(kfmService.updateKfm(kfm));
    }

    /**
     * 删除kfm
     */
    @ApiOperation("删除kfm")
//    @RequiresPermissions("kaifamiao:kfm:remove")
    @Log(title = "kfm", businessType = BusinessType.DELETE)
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(kfmService.deleteKfmByIds(ids));
    }
}
