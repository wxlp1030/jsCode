package com.ruoyi.web.controller.system;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.system.domain.Guestbook;
import com.ruoyi.system.service.IGuestbookService;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

import javax.servlet.http.HttpServletResponse;

/**
 * guestBookController
 * 
 * @author wx
 * @date 2022-09-03
 */
@Controller
@RequestMapping("/guestBook")
@CrossOrigin("*")
public class GuestbookController extends BaseController
{
    private String prefix = "system/guestBook";

    @Autowired
    private IGuestbookService guestbookService;

    @RequiresPermissions("system:guestBook:view")
    @GetMapping()
    public String guestBook()
    {
        return prefix + "/guestBook";
    }

    /**
     * 查询guestBook列表
     */
//    @RequiresPermissions("system:guestBook:list")
    @GetMapping("/list")
    @ResponseBody
    public TableDataInfo list(Guestbook guestbook, HttpServletResponse response)
    {
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Cache-Control", "no-cache");
        startPage();
        List<Guestbook> list = guestbookService.selectGuestbookList(guestbook);
        return getDataTable(list);
    }

    /**
     * 导出guestBook列表
     */
//    @RequiresPermissions("system:guestBook:export")
    @Log(title = "guestBook", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(Guestbook guestbook)
    {
        List<Guestbook> list = guestbookService.selectGuestbookList(guestbook);
        ExcelUtil<Guestbook> util = new ExcelUtil<Guestbook>(Guestbook.class);
        return util.exportExcel(list, "guestBook数据");
    }

    /**
     * 新增guestBook
     */
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    /**
     * 新增保存guestBook
     */
//    @RequiresPermissions("system:guestBook:add")
    @Log(title = "guestBook", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(Guestbook guestbook)
    {
        return toAjax(guestbookService.insertGuestbook(guestbook));
    }

    /**
     * 修改guestBook
     */
//    @RequiresPermissions("system:guestBook:edit")
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Long id, ModelMap mmap)
    {
        Guestbook guestbook = guestbookService.selectGuestbookById(id);
        mmap.put("guestbook", guestbook);
        return prefix + "/edit";
    }

    /**
     * 修改保存guestBook
     */
//    @RequiresPermissions("system:guestBook:edit")
    @Log(title = "guestBook", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(Guestbook guestbook)
    {
        return toAjax(guestbookService.updateGuestbook(guestbook));
    }

    /**
     * 删除guestBook
     */
//    @RequiresPermissions("system:guestBook:remove")
    @Log(title = "guestBook", businessType = BusinessType.DELETE)
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(guestbookService.deleteGuestbookByIds(ids));
    }
}
