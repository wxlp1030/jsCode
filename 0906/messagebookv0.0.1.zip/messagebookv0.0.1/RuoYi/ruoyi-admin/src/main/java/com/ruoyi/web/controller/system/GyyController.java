package com.ruoyi.web.controller.system;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.system.domain.Gyy;
import com.ruoyi.system.service.IGyyService;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * gyyController
 * 
 * @author ruoyi
 * @date 2022-09-05
 */
@Controller
@RequestMapping("/system/gyy")
public class GyyController extends BaseController
{
    private String prefix = "system/gyy";

    @Autowired
    private IGyyService gyyService;

    @RequiresPermissions("system:gyy:view")
    @GetMapping()
    public String gyy()
    {
        return prefix + "/gyy";
    }

    /**
     * 查询gyy列表
     */
    @RequiresPermissions("system:gyy:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(Gyy gyy)
    {
        startPage();
        List<Gyy> list = gyyService.selectGyyList(gyy);
        return getDataTable(list);
    }

    /**
     * 导出gyy列表
     */
    @RequiresPermissions("system:gyy:export")
    @Log(title = "gyy", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(Gyy gyy)
    {
        List<Gyy> list = gyyService.selectGyyList(gyy);
        ExcelUtil<Gyy> util = new ExcelUtil<Gyy>(Gyy.class);
        return util.exportExcel(list, "gyy数据");
    }

    /**
     * 新增gyy
     */
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    /**
     * 新增保存gyy
     */
    @RequiresPermissions("system:gyy:add")
    @Log(title = "gyy", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(Gyy gyy)
    {
        return toAjax(gyyService.insertGyy(gyy));
    }

    /**
     * 修改gyy
     */
    @RequiresPermissions("system:gyy:edit")
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Long id, ModelMap mmap)
    {
        Gyy gyy = gyyService.selectGyyById(id);
        mmap.put("gyy", gyy);
        return prefix + "/edit";
    }

    /**
     * 修改保存gyy
     */
    @RequiresPermissions("system:gyy:edit")
    @Log(title = "gyy", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(Gyy gyy)
    {
        return toAjax(gyyService.updateGyy(gyy));
    }

    /**
     * 删除gyy
     */
    @RequiresPermissions("system:gyy:remove")
    @Log(title = "gyy", businessType = BusinessType.DELETE)
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(gyyService.deleteGyyByIds(ids));
    }
}
